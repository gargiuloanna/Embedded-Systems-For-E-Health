/*
 * Source Code for final project of Embedded Systems for E-Health
 * Academic year 2021-2022
 * Digital Health and Bioinformatic Engineering
 *
 * KY028.c
 *
 *  Created on: Jun 8, 2022
 *      Author: Team 3
 *      Members: Ceglia Salvatore
 *               Ferrara Luigina
 *               Gargiulo Anna
 *               Kárason Halldór
 *
 */
#include "KY028.h"


/*The function initializes the digital temperature sensor and returns the status of the operation */
HAL_StatusTypeDef temp_sensor_init(ADC_HandleTypeDef* hadc){

	return HAL_ADC_Start(hadc);
}

/*The function reads and returns the raw measure from the ADC*/
uint32_t __temp_sensor_read(ADC_HandleTypeDef* hadc){

	uint32_t rawValue;

	if(HAL_ADC_PollForConversion(hadc, HAL_MAX_DELAY) == HAL_OK){

		rawValue = HAL_ADC_GetValue(hadc); //raw value from the sensor to be converted

	}else{

		rawValue = -1;
	}
    return rawValue;

}

/*
 * The function returns the temperature in °C computed from the ADC raw value.
 * The formula that is used to the conversion is the B equation.
 */
float temperature_read(ADC_HandleTypeDef* hadc){

    uint32_t rawValue;
	float R; // R is the variable resistance
	float temp;

	rawValue = __temp_sensor_read(hadc);
	R = (4095.0/rawValue)-1; //from the rawValue, R is computed considering a voltage divider
	R = POTENTIOMETER_SERIES / R;

    //B equation: 1/T = 1/T0 + 1/B*ln(R/R0)
	//the temperature is in K
    temp = R/NOMINAL_RESISTANCE;
    temp = log(temp);
    temp /= BCOEFFICIENT;
    temp += 1.0 / NOMINAL_TEMPERATURE;
    temp = 1.0 / temp;
    temp -= 273.15;//convert in C°

    return temp;

}
