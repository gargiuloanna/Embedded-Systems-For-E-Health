/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
/* Private includes ----------------------------------------------------------*/
#include "MAX32664.h"
#include "ds1307.h"
#include "ssd1306.h"
#include "adc.h"
#include "KY028.h"
#include <print_interface.h>
/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define GOOD_MES 12
#define CHECK_FOR_ALARMS 1
#define TEMP_CRITIC 37.5
#define TEMP_WARNING 37
#define OXY_CRITIC 90
#define OXY_WARNING 94
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
MAX32664 max;
date_time_t datetime;
int counter = 0;
float avg_hr_samp[2] = {0.0};
float avg_oxy_samp[2] = {0.0};
float avg_temp_samp[2] = {0.0};
float temperature;
float temp_array[GOOD_MES] = {0.0};
float hr_array[GOOD_MES] = {0.0};
float oxy_array[GOOD_MES] = {0.0};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern DMA_HandleTypeDef hdma_i2c2_tx;
extern I2C_HandleTypeDef hi2c2;
extern TIM_HandleTypeDef htim10;
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
  while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles TIM1 update interrupt and TIM10 global interrupt.
  */
void TIM1_UP_TIM10_IRQHandler(void)
{
  /* USER CODE BEGIN TIM1_UP_TIM10_IRQn 0 */

  /* USER CODE END TIM1_UP_TIM10_IRQn 0 */
  HAL_TIM_IRQHandler(&htim10);
  /* USER CODE BEGIN TIM1_UP_TIM10_IRQn 1 */

  /* USER CODE END TIM1_UP_TIM10_IRQn 1 */
}

/**
  * @brief This function handles I2C2 event interrupt.
  */
void I2C2_EV_IRQHandler(void)
{
  /* USER CODE BEGIN I2C2_EV_IRQn 0 */

  /* USER CODE END I2C2_EV_IRQn 0 */
  HAL_I2C_EV_IRQHandler(&hi2c2);
  /* USER CODE BEGIN I2C2_EV_IRQn 1 */

  /* USER CODE END I2C2_EV_IRQn 1 */
}

/**
  * @brief This function handles DMA1 stream7 global interrupt.
  */
void DMA1_Stream7_IRQHandler(void)
{
  /* USER CODE BEGIN DMA1_Stream7_IRQn 0 */

  /* USER CODE END DMA1_Stream7_IRQn 0 */
  HAL_DMA_IRQHandler(&hdma_i2c2_tx);
  /* USER CODE BEGIN DMA1_Stream7_IRQn 1 */

  /* USER CODE END DMA1_Stream7_IRQn 1 */
}
/*
 * The function inserts a new sample (measurement) at the index position of the array.
 */
void measurements_to_average(float *ptr_array, float new_sample, int index)
{
	ptr_array[index] = new_sample;
}
/*
 * The function computes the average of the measurements. It inserts into the first position of a new array
 * the average while in the second position there is the number of the good samples (measurements that are not zero)
 * on which the average is computed.
 */
void average(float *ptr_array, float *ptr_avg_samp_array){

	float sum = 0.0;
	int good_samples = 0; // number of samples that are usable

	for (int i = 0; i < GOOD_MES; i++)
	{
		if (ptr_array[i] != 0)
		{
			sum = sum + ptr_array[i]; // sum of all usable values
			good_samples++;
		}
	}
	if(good_samples == 0)
	{
	   ptr_avg_samp_array[0] =  0.0;
	   ptr_avg_samp_array[1] = 0.0;
	}
	else
	{
	   ptr_avg_samp_array[0] = sum / good_samples;
	   ptr_avg_samp_array[1] = (float)good_samples;
	}
}
/*
 * The timer callback manages the prints on the OLED display and on the interface UART.
 * The measurements (body temperature, heart rate, blood oxygenation) are perfomed every 5 seconds
 * and shown on the UART with the associated timestamp. After a minute, the good measurements are averaged
 * and the aggregated values are shown both on the display and on the UART. If these values are not compliant
 * with the thresholds of Covid19 regulations, some alerts will be risen and shown on the display
 * according to the severity.
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if (htim->Instance == TIM10 )
	{
		ds1307rtc_get_date_time(&datetime);
		print_onUART("-----------------------------------------------------------------------------\r\n");
		print_onUART("Timestamp of the measurement: %d/%d/%d - %d:%d:%d\r\n", datetime.date, datetime.month, datetime.year, datetime.hours,datetime.minutes,datetime.seconds);
		temperature = temperature_read(&hadc1);
		measurements_to_average(temp_array, temperature, counter);
		print_onUART("Temperature: %.2f\r\n", temperature);
		read_sensor(&max);
		if (max.algorithm_state != 3) //the finger is not present or it is not located in a good position
		{
			 print_onUART("Please, place index finger on the sensor to measure accurately\r\n");
			 ssd1306_Clear();
			 print_onDISPLAY(22,1,"Finger is not");
			 print_onDISPLAY(36,15,"detected");
		}
		else
		{
			ssd1306_Clear();
			print_onDISPLAY(15,1,"Loading vitals");
			print_onDISPLAY(36,15,"...Wait...");
		}
		measurements_to_average(oxy_array, (float) max.oxygen, counter);
		if (max.confidence < 90) //the confidence is linked to the heart-rate measurement
		{
			 measurements_to_average(hr_array, 0.0, counter);
		}
		else
		{
			 measurements_to_average(hr_array, (float) max.heart_rate, counter);

		}
		 print_onUART("Bpm: %d           Spo2: %d\r\n", max.heart_rate, max.oxygen);
		 counter ++;
		 //to check if the aggregated values are compliant with the Covid19 thresholds
		 if(counter == CHECK_FOR_ALARMS && avg_temp_samp[0]!= 0.0 && avg_oxy_samp[0] != 0.0)
		 {
			 ssd1306_Clear();
			 //critic stage
			 if((int)avg_oxy_samp[0] < OXY_CRITIC)
			 {
				 print_onDISPLAY(1,1,"Critic oxygen");
			 }
			 if(avg_temp_samp[0] > TEMP_CRITIC)
			 {
				 print_onDISPLAY(1,15,"Critic temp");
			 }
			 //warning stage
			 else if ((int)avg_oxy_samp[0] >= OXY_CRITIC && (int)avg_oxy_samp[0] <= OXY_WARNING )
			 {
				 print_onDISPLAY(1,1,"Warning oxygen");
			 }
			 if (avg_temp_samp[0] >= TEMP_WARNING && avg_temp_samp[0] <= TEMP_CRITIC)
			 {
				 print_onDISPLAY(1,15,"Warning temp");
			 }
			 else
			 {
				 print_onDISPLAY(1,1,"Measurements done");
				 print_onDISPLAY(1,15,"Healthy parameters");
			 }

		 }
		 else if(counter == GOOD_MES) //after a minute (12 measurements)
		 {
		 	counter = 0;
		 	average(temp_array, avg_temp_samp);
		 	print_onUART("-----------------------------------------------------------------------------\r\n");
		 	print_onUART("Aggregate temperature: %.2f (average on %d/%d good measurements)\r\n", avg_temp_samp[0],  (int)avg_temp_samp[1], GOOD_MES);
		 	ssd1306_Clear();
		 	print_onDISPLAY(1, 1, "Temperature: %.2f", avg_temp_samp[0]);
		 	average(hr_array, avg_hr_samp);
		 	average(oxy_array, avg_oxy_samp);
		    print_onUART("Aggregate bpm in a minute: %d (average on %d/%d good measurements)\r\n", (int)avg_hr_samp[0],  (int)avg_hr_samp[1], GOOD_MES);
		 	print_onUART("Aggregate spo2 in a minute: %d (average on %d/%d good measurements)\r\n", (int)avg_oxy_samp[0],  (int)avg_oxy_samp[1], GOOD_MES);
		 	print_onDISPLAY(1, 15, "Bpm: %d  Spo2: %d", (int)avg_hr_samp[0], (int)avg_oxy_samp[0]);

	       }

	 }

}
