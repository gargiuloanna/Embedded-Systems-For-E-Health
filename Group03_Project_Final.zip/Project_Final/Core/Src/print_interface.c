/*
 * Source Code for final project of Embedded Systems for E-Health
 * Academic year 2021-2022
 * Digital Health and Bioinformatic Engineering
 *
 * MAX32664.c
 *
 *  Created on: Jun 8, 2022
 *      Author: Team 3
 *      Members: Ceglia Salvatore
 *               Ferrara Luigina
 *               Gargiulo Anna
 *               Kárason Halldór
 *
 */

#include <print_interface.h>

/*
 * The function prints on the UART interface
 */
void print_onUART(const char *str, ...)
{
	char msg[100];
	va_list args;
	va_start(args, str);
	vsprintf(msg, str, args);
	va_end(args);
	HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), HAL_MAX_DELAY);
}

/*
 * The function prints on the OLED display
 */
void print_onDISPLAY(int x, int y, const char *str, ...)
{
	char msg[100];
	va_list args;
	va_start(args, str);
	vsprintf(msg, str, args);
	va_end(args);
	ssd1306_SetCursor(x,y);
	ssd1306_WriteString(msg, Font_7x10);
	ssd1306_UpdateScreen();
}
