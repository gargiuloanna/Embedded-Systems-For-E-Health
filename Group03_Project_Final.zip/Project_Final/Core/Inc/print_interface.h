/*
 * Source Code for final project of Embedded Systems for E-Health
 * Academic year 2021-2022
 * Digital Health and Bioinformatic Engineering
 *
 * MAX32664.c
 *
 *  Created on: Jun 8, 2022
 *      Author: Team 3
 *      Members: Ceglia Salvatore
 *               Ferrara Luigina
 *               Gargiulo Anna
 *               Kárason Halldór
 *
 */

#ifndef INC_PRINT_INTERFACE_H_
#define INC_PRINT_INTERFACE_H_

#include "stdarg.h"
#include "usart.h"
#include "stdio.h"
#include "string.h"
#include "ssd1306.h"


void print_onUART(const char *str, ...);
void print_onDISPLAY(int x, int y, const char *str, ...);

#endif /* INC_PRINT_INTERFACE_H_ */
