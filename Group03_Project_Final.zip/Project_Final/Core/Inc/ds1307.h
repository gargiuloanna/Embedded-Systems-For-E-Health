/*
 * Source Code for final project of Embedded Systems for E-Health
 * Academic year 2021-2022
 * Digital Health and Bioinformatic Engineering
 *
 * ds1307.h 
 *
 *  Created on: Jun 8, 2022
 *      Author: Team 3 
 *      Members: Ceglia Salvatore
 *               Ferrara Luigina
 *               Gargiulo Anna
 *               Kárason Halldór
 *      
 */
#ifndef INC_DS1307_H_
#define INC_DS1307_H_

#include <stdint.h>

#define DS1307_OK 		(0)
#define DS1307_ERR		(-1)
#define DS1307_IC2_ERR	(-2)


struct date_time_s
{
	uint8_t     seconds;
	uint8_t     minutes;
	uint8_t     hours;
	uint8_t     day;
	uint8_t     date;
	uint8_t     month;
	uint8_t    year;
};

typedef struct date_time_s date_time_t;

int8_t ds1307rtc_init();

int8_t ds1307rtc_get_date_time(date_time_t* datetime);

int8_t ds1307rtc_set_date_time(const date_time_t* datetime);

int8_t ds1307rtc_dispose();

#endif /* INC_DS1307_H_ */