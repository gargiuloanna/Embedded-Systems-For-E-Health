/*
 * Source Code for final project of Embedded Systems for E-Health
 * Academic year 2021-2022
 * Digital Health and Bioinformatic Engineering
 *
 * fonts.h 
 *
 *  Created on: Jun 8, 2022
 *      Author: Team 3 
 *      Members: Ceglia Salvatore
 *               Ferrara Luigina
 *               Gargiulo Anna
 *               Kárason Halldór
 *      
 * Credits: https://github.com/RobertoBenjami/stm32_ssd1306_i2c_dma_hal
 */

#include "stdint.h"

#ifndef Fonts
#define Fonts

//
// Structure om font te definieren
//
typedef struct {
  const uint8_t FontWidth;    /*!< Font width in pixels */
  uint8_t FontHeight;         /*!< Font height in pixels */
  const uint16_t *data;       /*!< Pointer to data font data array */
} FontDef;

//
// De 3 fonts
//
extern FontDef Font_7x10;
extern FontDef Font_11x18;
extern FontDef Font_16x26;

#endif