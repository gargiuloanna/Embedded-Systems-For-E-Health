/*
 * Source Code for final project of Embedded Systems for E-Health
 * Academic year 2021-2022
 * Digital Health and Bioinformatic Engineering
 *
 * KY028.h
 *
 *  Created on: Jun 8, 2022
 *      Author: Team 3
 *      Members: Ceglia Salvatore
 *               Ferrara Luigina
 *               Gargiulo Anna
 *               Kárason Halldór
 *
 */

#ifndef INC_KY028_H_
#define INC_KY028_H_


#include "adc.h"
#include "math.h"


/*Operating constants*/
#define NOMINAL_RESISTANCE (10000)
#define POTENTIOMETER_SERIES (10000)
/*B equation constants*/
#define NOMINAL_TEMPERATURE (298.15) //298.15 K = 25°C
#define BCOEFFICIENT (3950) //in K



HAL_StatusTypeDef temp_sensor_init(ADC_HandleTypeDef* hadc);
uint32_t __temp_sensor_read(ADC_HandleTypeDef* hadc);
float temperature_read(ADC_HandleTypeDef* hadc);



#endif /* INC_KY028_H_ */
